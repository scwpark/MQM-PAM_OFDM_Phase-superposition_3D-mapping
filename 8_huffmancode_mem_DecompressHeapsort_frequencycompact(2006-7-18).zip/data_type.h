#ifndef  _DATA_TYPE_H_
#define  _DATA_TYPE_H_

#ifndef UCHAR
typedef  unsigned char UCHAR;
#endif

#ifndef USHORT
typedef  unsigned short USHORT;
#endif

#ifndef UINT
typedef  unsigned int UINT;
#endif


#ifndef NULL
#define NULL 0
#endif

#endif