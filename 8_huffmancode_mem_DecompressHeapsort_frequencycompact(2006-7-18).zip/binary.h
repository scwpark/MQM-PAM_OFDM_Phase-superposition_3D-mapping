#ifndef _BINARYSEARCH_H_
#define _BINARYSEARCH_H_


int BinarySearch( void *base, int N, int width, void *val, int (__cdecl *compare )(const void *elem1, const void *elem2 ) );


#endif