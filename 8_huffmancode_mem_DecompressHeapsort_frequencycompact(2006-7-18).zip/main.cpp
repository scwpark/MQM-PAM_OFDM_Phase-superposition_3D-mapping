#include <string.h>
#include <malloc.h>

#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>

#include "binarysearch.h"
#include "huffcode.h"
#include "heapsort.h"
#include "bitset.h"

// 1) header
typedef struct
{
	//ceilin(�Ѻ�Ʈ�� / 8) �� ����Ʈ�� , �Ѻ�Ʈ��% 8 ��Ʈ��������  
	// �ڷᰡ ����� �� ũ�⸦ ���
	double total_bits;
	unsigned int x_column; // x byte�� 
	unsigned int m; // m bit ������ ���� ����Ÿ�̴�.
	int	  filename_length;
	char  filename[1000];
	// int   reserved1;
	// int   reserved2;
	// char  *data;
} CompressHeader;


/*------------------------------------------------
1. CompressHeader + Frequency + compressed data


------------------------------------------------*/
/*----------------------------------------------
  	double total_bits; 
	total_bits= 1024;
	total_bits = (total_bits *1024*1024*2 -1) *8 +7;

	unsigned int t, tt;
	_getbyte( total_bits, &t, &tt); 


  total_bits : t : tt	== 8 : 1 : 7	( (1-1)�� 7��° ��Ʈ����)
						== 9 : 2 : 0	( (2-1)�� 0��° ��Ʈ����)
						== 1 : 1 : 0	
  ----------------------------------------------*/
void _getbyte( double bits_number, unsigned int *x_col, unsigned int *m_bits )
{
	double  temp;
	unsigned int x;
#if 0
	*x_col = x = bits_number/CHAR_BITS;

	temp = x * CHAR_BITS;
	*m_bits = bits_number - temp;

	if( *m_bits != 0.0)
		*x_col += 1;
#else
	*x_col = x = bits_number/CHAR_BITS;

	temp = x * CHAR_BITS;
	*m_bits = bits_number - temp;


	// 8�� ����� �ƴ� ��.
	if( *m_bits != 0.0)
	{
		*x_col += 1;
	}

	*m_bits -= 1;

#endif
}


#include "compare.h"
int fc_compare_value( const void * e1, const void *e2)
{
	return UCharCompare(&((Freq_Compact*)e1)->value, &((Freq_Compact*)e2)->value);

}


int Find_Huffmancode( Freq_Compact_Man *m_pfcm, unsigned char decompressed_data)
{
	int x ;
	


	for( x= 0; x < m_pfcm->count ; x++)
	{
		if( m_pfcm->freq_list[x].value == decompressed_data )
			return x;
	}

	return -1;
}
#include <string.h>
int fc_compare_huffmancode( const void * e1, const void *e2)
{
	return strcmp(((Freq_Compact*)e1)->huffman_code, ((Freq_Compact*)e2)->huffman_code);

}

int Find_Decompressed( Freq_Compact_Man *m_pfcm, char *compressed_data)
{
	int x ;
	for( x= 0; x < m_pfcm->count ; x++)
	{
		if( !strcmp(m_pfcm->freq_list[x].huffman_code, compressed_data ) )
			return x;
	}

	return -1;
}

/*//////////////////////////////////////////////////////////////////////////////////////
1. ��� :  '0'�� '1'�� �̷���� string�� ������ to_target[*to_x_col]�� *to_mth_bit��° 
			��Ʈ���� ����Ѵ�.
2. Parameter :
1) char *to_target		:
2) int  *to_x_col		: *to_mth_bit�� ��ġ�� 8�̻��� �Ǹ� +1 �����Ѵ�.
3) int  *to_mth_bit		: *to_mth_bit�� ��ġ�� 8�� �Ǹ� 0�� �ȴ�.
                            
4) const char *string	: '0'�� '1'�� �̷���� ���ڿ��� write�� �����̴�.

	int x_col, y;
	char b[MAX_SIZE];
	char tmp[100] ="0100";
	memset( b, 0xFF, sizeof(char) * MAX_SIZE );
	x_col = 1, y =6;
	WriteStringToBits(b, &x_col, &y,  tmp );
	WriteStringToBits(b, &x_col, &y,  tmp );

	x_col = 1, y =7;
	ReadStringToBits(b, &x_col, &y, 3, tmp);
	ReadStringToBits(b, &x_col, &y, 4, tmp);
	ReadStringToBits(b, &x_col, &y, 4, tmp);
	ReadStringToBits(b, &x_col, &y, 4, tmp);

/////////////////////////////////////////////////////////////////////////////////////*/
void WriteStringToBits(unsigned char *to_target, int *to_x_col, int *to_mth_bit, const char *string )
{
	int length = strlen(string);
	int loop;
	char ch;

	for ( loop = 0; loop < length; loop++)
	{
		ch = string[loop];
		if ( ch == '1' )
			SetCharBit(to_target[*to_x_col],   (*to_mth_bit)++);
		else if ( ch== '0' )
			ClearCharBit(to_target[*to_x_col], (*to_mth_bit)++);
		else
		{
			printf("[WriteStringToBits]error %c\n", ch);
			return ;
		}

		*to_x_col += Floaring( *to_mth_bit, CHAR_BITS);
		*to_mth_bit %= CHAR_BITS;
	}

}

void ReadStringToBits(unsigned char *from_target, int *from_x_col, int *from_mth_bit, int readed_bit_length, char *string )
{
	int loop;
	char ch;

	for( loop = 0 ; loop < readed_bit_length ; loop++ )
	{
		ch = '0' + GetCharBit(from_target[*from_x_col], (*from_mth_bit)++);

		if( ch == '1' || ch == '0' )
		{
			string[ loop	 ] = ch;
			string[ loop + 1 ] = NULL;
		}

		*from_x_col += Floaring( *from_mth_bit, CHAR_BITS);
		*from_mth_bit %= CHAR_BITS;

	}

}

void  MakeHuffmanTreeandHuffmanCode(unsigned	char * original_data, int size, Freq		*result)
{
	//////////////////////////////////////////////////////////////////////////////////////
	// int Freq_bytes;
	int value;
	int frequency;
	int loop;





	// 1. �󵵰� ���� �����κ��� ���� ������ �������� ����
	GetMode( original_data, size, &value, &frequency, result);


	for( loop = 0; loop < result->number ; loop++)
	{
		if( loop > 128)
			printf("--");
		printf("%d��° ������(%x) �󵵼�(%d)\n", loop+1, 
			 result->value[loop],  result->freq[loop]);
	}



	
	//////////////////////////////////////////////////////////////////////////////////////
	// 2. make huffman tree
	H_node_manager  man;
	H_node          hnode[MAX_NODE];
	man.root  = hnode;
	man.total = result->number ;
	memset(hnode, 0x0, sizeof(H_node) * MAX_NODE);
	Convert2Hnode( result, man.root);


	// H_node  f[MAX_NODE];
	H_node  f[MAX_NODE*2]; // depth  Warning
	H_node  node;
	int x; 

	memset(f, 0x0, sizeof(H_node) * MAX_NODE );

	int t;
	for( x = 0 ;  man.total > 1; x+=2)
	{
		
		DeleteHeap( (void *)man.root, &man.total, sizeof(H_node), &f[x],    HnodeCompareDSC);
		DeleteHeap( (void *)man.root, &man.total, sizeof(H_node), &f[x+1],    HnodeCompareDSC);
		// DeleteHeapPos( (void *)man.root, &man.total, sizeof(H_node), &f[x], man.total-1, HnodeCompareDSC);
		// DeleteHeapPos( (void *)man.root, &man.total, sizeof(H_node), &f[x+1], man.total-1, HnodeCompareDSC);
		
		memset(&node, 0x0, sizeof(H_node ) );
		node.left  = &f[x]  ;
		node.right = &f[x+1];

		node.freq  = f[x].freq + f[x+1].freq ;
		

		InsertHeap( (void *)man.root, &man.total, sizeof(H_node), &node, HnodeCompareDSC);
	}

	//////////////////////////////////////////////////////////////////////////////////////
	// 3. make huffman code
	Make_HuffmanCode ( man.root, "", "", result);

}

#if 1
int CreateFreq_Compact_Table( Freq *result, Freq_Compact_Man *fcm)
{
	int loop;
	int Freq_bytes ;
	//////////////////////////////////////////////////////////////////////////////////////
	// Frequency table
	fcm->count = result->number ;

#if 1
	fcm->freq_list = ( Freq_Compact *) malloc( sizeof( Freq_Compact ) * fcm->count);
#else
	Freq_Compact  m_compact[MAX_COLUMN];
	fcm->freq_list = m_compact;
#endif

	Freq_bytes = 0;
	for( loop = 0 ; loop < fcm->count; loop++)
	{
		fcm->freq_list[loop].value  = result->value[loop] ;
		fcm->freq_list[loop].freq   = result->freq[loop];
		fcm->freq_list[loop].length =  strlen(result->huffman_code[loop] );
		strcpy( fcm->freq_list[loop].huffman_code, result->huffman_code[loop] );

		Freq_bytes +=  GETSIZE(Freq_Compact_Man, count)
					+ GETSIZE(Freq_Compact    , value)
					+ GETSIZE(Freq_Compact    , freq )
					+ GETSIZE(Freq_Compact    , length )
					+ Ceiling (fcm->freq_list[loop].length, CHAR_BITS) ;
			
	}

////////////////////////////////////////////////////////////////////
	return Freq_bytes;
}
#endif

void DeleteFreq_Compact_Table(Freq_Compact_Man *fcm)
{
	
	free(fcm->freq_list  );
}


int   MakeCompressHeader(CompressHeader *pheader, Freq_Compact_Man *fcm, char *filename)
{
	int loop;
	int CompressedHeader_bytes ;
	double	dcompressed_bits = 0;


	memset( pheader, 0x0, sizeof(CompressHeader));
	strcpy( pheader->filename , filename);
	pheader->filename_length = strlen(pheader->filename ) + 1;


	for( loop = 0; loop < fcm->count ; loop++)
	{
		dcompressed_bits += (double)strlen( fcm->freq_list[loop].huffman_code ) * (double)fcm->freq_list[loop].freq; // 2Giga Bits = 8 * 256MB�Ѵ� ��츦 ����


	}

	pheader->total_bits = dcompressed_bits;
	_getbyte(dcompressed_bits,  &pheader->x_column , &pheader->m );

	CompressedHeader_bytes = 
					GETSIZE(CompressHeader, total_bits)
				+   GETSIZE(CompressHeader, x_column )
				+	GETSIZE(CompressHeader, m )
				+   GETSIZE(CompressHeader, filename_length )
				+   pheader->filename_length ;

	return CompressedHeader_bytes;

}

unsigned char * Write_Freq_Compact_Man( const Freq_Compact_Man *fcm, unsigned char ** target)
{
	int loop;
	unsigned char * move_p = *target ;

	memcpy( move_p, &fcm->count, GETSIZE(Freq_Compact_Man    , count) );
	move_p += GETSIZE(Freq_Compact_Man    , count);

	int x_col =0, m = 0;
	for( loop = 0; loop < fcm->count ; loop++)
	{
		
		memcpy( move_p, &fcm->freq_list[loop].value,  GETSIZE(Freq_Compact    , value) );  move_p += GETSIZE(Freq_Compact    , value) ;
		memcpy( move_p, &fcm->freq_list[loop].freq,   GETSIZE(Freq_Compact    , freq)  );  move_p += GETSIZE(Freq_Compact    , freq) ;
		memcpy( move_p, &fcm->freq_list[loop].length, GETSIZE(Freq_Compact    , length));  move_p += GETSIZE(Freq_Compact    , length) ;
		
#if 0
		memcpy( move_p, fcm->freq_list[loop].huffman_code, fcm->freq_list[loop].length  ); move_p += fcm->freq_list[loop].length ;

#else   // compact�ϰ� ����
		x_col =0, m = 0;
		WriteStringToBits( move_p, &x_col, &m, fcm->freq_list[loop].huffman_code);
		move_p += Ceiling ( fcm->freq_list[loop].length, CHAR_BITS);
#endif
	}

	return *target=move_p;
}

unsigned int Read_Freq_Compact_Man(const Freq_Compact_Man *fcm, unsigned char ** target)
{
	unsigned int total_data_freq = 0;
	unsigned int loop;
	int x_col =0, m = 0;
	for( loop = 0; loop < fcm->count ; loop++)
	{
		memcpy( &fcm->freq_list[loop].value,			*target,  GETSIZE(Freq_Compact    , value) );  
		*target += GETSIZE(Freq_Compact    , value) ;

		memcpy( &fcm->freq_list[loop].freq,			*target,   GETSIZE(Freq_Compact    , freq)  );  
		*target += GETSIZE(Freq_Compact    , freq) ;
		total_data_freq += fcm->freq_list[loop].freq;

		memcpy( &fcm->freq_list[loop].length,		*target, GETSIZE(Freq_Compact    , length));  
		*target += GETSIZE(Freq_Compact    , length) ;

#if 0
		memcpy( fcm->freq_list[loop].huffman_code,	*target, fcm->freq_list[loop].length  );  
		*target += fcm->freq_list[loop].length ;
#else   // compact�ϰ� ����� ���� read
		x_col =0, m = 0;
		ReadStringToBits(*target, &x_col, &m, fcm->freq_list[loop].length, fcm->freq_list[loop].huffman_code );
		*target += Ceiling ( fcm->freq_list[loop].length, CHAR_BITS);
#endif
	}

	return total_data_freq;
	
}

#include "binarysearch.h"
unsigned char * Compress(  unsigned char * original_data, int size , int *compressed_bytes)
{
	CompressHeader cheader;
	int		loop;
	int		compressed_bits = 0;  

	int		Freq_bytes = 0;
	int		total_bytes = 0;
	Freq    freq;
	Freq_Compact_Man  fcm;
	unsigned char *m_pcompressed_data;



	// 1. Make huffmanTree and Make Huffman Code
	MakeHuffmanTreeandHuffmanCode(original_data, size, &freq);


	// 2. Create Freq_Compact_Man with Freq and get Freq_bytes
	Freq_bytes = CreateFreq_Compact_Table( &freq, &fcm);
	//////////////////////////////////////////////////////////////////////////////////////

	// 3. ����� �ڷ��� ũ��.
	int CompressedHeader_bytes = MakeCompressHeader(&cheader, &fcm, "a\\a.exe");


	// 4. ����� ���� �Ҵ� == CompressHeader + Frequency + compressed data
	*compressed_bytes = total_bytes =	CompressedHeader_bytes
				+	Freq_bytes 
				+	cheader.x_column ;
	
	printf("[compressdHeader] %d + [frequence_table_bytes] %d + \n",
				CompressedHeader_bytes, Freq_bytes);

	printf(" {���� ���� data [%d]bits(%dbytes)�� }[%lf]bits(%dbytes)�� ����= ������[%d]bytes\n",
				size*CHAR_BITS, size, cheader.total_bits, cheader.x_column, total_bytes);

	// 5. �� ���� �Ҵ�.
	if( (m_pcompressed_data = (unsigned char *) malloc( total_bytes ) ) == NULL )
		return NULL;

	memset( m_pcompressed_data, 0x0, total_bytes );

	unsigned char * move_p = m_pcompressed_data;

	// 6. Write Data
	// 1) write the information of Header
	memcpy( move_p, &cheader , CompressedHeader_bytes);
	
	
	// 2) Write the Frequency Table
	move_p = move_p + CompressedHeader_bytes ;

	Write_Freq_Compact_Man( &fcm, &move_p); 

	// 3) Write the compressed data to memory
	int x_col = 0;
	int m_bit = 0;
	int pos   = 0;

	HeapSort(fcm.freq_list, fcm.count, sizeof(Freq_Compact), fc_compare_value);
	Freq_Compact tt;
	
	for (loop = 0; loop < size; loop++)
	{
		// pos =  Find_Huffmancode(&fcm, original_data[loop]) ;
		tt.value = original_data[loop];
		pos = BinarySearch( fcm.freq_list, fcm.count,  sizeof(Freq_Compact), &tt ,fc_compare_value);
		if( pos == -1)
			printf("[error]Compress\n");
		WriteStringToBits( move_p , &x_col , &m_bit, fcm.freq_list[pos].huffman_code  );
	}

	// 7. Delete Freq_Compact_Table
	DeleteFreq_Compact_Table(&fcm);

	return m_pcompressed_data;

}



unsigned char * DeCompress(unsigned char *m_pcompressed_data, unsigned char ** original_data, int* size )
{

	int		loop;
	int		compressed_bits = 0;  
	double	dcompressed_bits = 0;
	int		Freq_bytes = 0;
	int		total_bytes = 0;
	unsigned char   *copy_compressed_data = m_pcompressed_data;

	// compressheader
	CompressHeader cheader;

	// Frequency table
	Freq_Compact_Man fcm;

	Freq_Compact  m_compact[MAX_COLUMN];
	fcm.freq_list = m_compact;


	// 1. read CompressHeader
	memcpy( &cheader.total_bits,		copy_compressed_data, GETSIZE(CompressHeader, total_bits) ); 
	copy_compressed_data+=GETSIZE(CompressHeader, total_bits);

	memcpy( &cheader.x_column,			copy_compressed_data, GETSIZE(CompressHeader, x_column) );
	copy_compressed_data+=GETSIZE(CompressHeader, x_column);

	memcpy( &cheader.m,					copy_compressed_data, GETSIZE(CompressHeader, m) );
	copy_compressed_data+=GETSIZE(CompressHeader, m);

	memcpy( &cheader.filename_length,	copy_compressed_data, GETSIZE(CompressHeader, filename_length) );
	copy_compressed_data+=GETSIZE(CompressHeader, filename_length);

	memcpy( cheader.filename,			copy_compressed_data, cheader.filename_length);
	copy_compressed_data+=cheader.filename_length;


	// 2. Read Frequency table
	memcpy( &fcm.count, copy_compressed_data, GETSIZE(Freq_Compact_Man    , count) );
	copy_compressed_data += GETSIZE(Freq_Compact_Man    , count);

	unsigned int total_data_freq = Read_Freq_Compact_Man( &fcm, &copy_compressed_data);






	// 3. reads compressed data & converts compressed data to decompressed data
	int x = 0;
	int x_col = 0, copy_x_col;
	int m_bit = 0, copy_m_bit;
	int read_bit = 1;

	int pos   = 0;
	char read_data[300];

	if( (*original_data = (unsigned char *) malloc ( total_data_freq ) ) == NULL )
		return NULL;

#if 1	

	HeapSort(fcm.freq_list, fcm.count, sizeof(Freq_Compact), fc_compare_huffmancode);
	Freq_Compact tt;

	*size = 0;
	while(  cheader.total_bits > x_col * CHAR_BITS + m_bit )
	{
		copy_x_col = x_col;
		copy_m_bit = m_bit;
		ReadStringToBits(copy_compressed_data , &x_col, &m_bit, read_bit, read_data );

		// pos =  Find_Decompressed(&fcm, read_data) ;
		strcpy( tt.huffman_code , read_data);
		pos = BinarySearch( fcm.freq_list, fcm.count,  sizeof(Freq_Compact), &tt ,fc_compare_huffmancode);

		if (pos >= 0) // found
		{
			read_bit = 1;

			// write original_data
			original_data[0][x++] = fcm.freq_list[pos].value;
			// printf("%s : %x\n", fcm.freq_list[pos].huffman_code, fcm.freq_list[pos].value);
			*size += 1;
			
		}
		else
		{
			x_col = copy_x_col;
			m_bit = copy_m_bit;
			read_bit++;


		}
	}
#endif

	printf("size(%d) total_bits(%lf=%d) x��(%d)�� %d��° ��Ʈ�� �պ�Ʈ���� ��ϵȴ�.\n", 
		*size, cheader.total_bits, x_col * CHAR_BITS + m_bit, x_col, m_bit);
	return *original_data;

}

void Close_Compress_Decompress(unsigned char *data)
{
	if( data)
		free(data);
}


////////////////////////////////////////////////////////////////////////////

#if 0
	#define MAX_SIZE  256
	char data[MAX_SIZE] = { 0xFF};
#else
	#define MAX_SIZE  10
	char data[MAX_SIZE] ={-1,1,2,3,-1,0,0,2,2,2};
#endif

void  main3()
{
	unsigned char t ;
	// int value;
// 	int frequency;
	int loop;


	unsigned char *compressed_data;

#if 0
	for(loop = 1 , t = 0 ; loop < MAX_SIZE ; t++, loop++ )
	{
		data[loop] = data[loop -1] - 0x01;
	}
#endif



	//////////////////////////////////////////////////////////////////////////////////////
	// memory compress
	int comp_size ;
	compressed_data = Compress ( (unsigned char*)data, MAX_SIZE, &comp_size );

	//////////////////////////////////////////////////////////////////////////////////////
	// memory decompress
	unsigned char *original_data;
	int  size;
	DeCompress(compressed_data , &original_data , &size );

	for( loop = 0 ; loop < MAX_SIZE ; loop++)
	{
		if( (unsigned char) original_data[loop] != (unsigned char) data[loop])
			printf("EEE[%d] %x %x\n", loop, original_data[loop] , data[loop]);

	}

	printf("\n");

	//////////////////////////////////////////////////////////////////////////////////////

	Close_Compress_Decompress(compressed_data);
	Close_Compress_Decompress(original_data);	
}

// a.jpg => compress => a1.huf�� ����=> decompress =>a1.jpg
void main2()
{
	FILE *in, *out, *comp_out;
	unsigned char *a;
	unsigned char *compressed_data;

	struct _stat buf;
	int result;
	char buffer[] = "a.bmp";

	/* Get data associated with "stat.c": */
	result = _stat( buffer, &buf );

	/* Check if statistics are valid: */
	if( result != 0 )
		perror( "Problem getting information" );
	else
	{
		/* Output some of the statistics: */
		printf( "File size     : %ld\n", buf.st_size );
		printf( "Drive         : %c:\n", buf.st_dev + 'A' );
		printf( "Time modified : %s", ctime( &buf.st_atime ) );
	}

	fcloseall();
	//////////////////////////////////////////////////////////////////////////////////////

	if( (a= (unsigned char*)malloc( buf.st_size )) == NULL)
		return;

	if( (in = fopen(buffer, "rb")) == NULL || (out=fopen("a1.bmp", "wb"))==NULL || (comp_out=fopen("a1.huf", "wb"))==NULL  )
	{
		fcloseall();
		return;
	}

	fread(a, buf.st_size, 1, in);


	//////////////////////////////////////////////////////////////////////////////////////
	int comp_size;
	compressed_data = Compress ( a, buf.st_size, &comp_size);
	
	fwrite(compressed_data, comp_size, 1, comp_out);

	//////////////////////////////////////////////////////////////////////////////////////
	unsigned char *original_data;
	int  size;
	DeCompress(compressed_data , &original_data , &size );


	// ��
	for( int loop = 0 ; loop < size ; loop++)
	{
		//if( (unsigned char) original_data[loop] != (unsigned char) a[loop])
		//	printf("EEE[%d] %x %x\n", loop, original_data[loop] , a[loop]);

	}

	//////////////////////////////////////////////////////////////////////////////////////
	fwrite(original_data, size, 1, out);

	printf("\n");

	//////////////////////////////////////////////////////////////////////////////////////

	Close_Compress_Decompress(compressed_data);
	Close_Compress_Decompress(original_data);	

	free(a);

	fclose(in);
	fclose(out);
	fclose(comp_out);


}

// a1.huf => a.jpg
void main1()
{
	FILE  *out, *comp_out;
	unsigned char *a;


	//////////////////////////////////////////////////////////////////////////////////////
	struct _stat buf;
	int result;
	char buffer[] = "a1.huf";

	/* Get data associated with "stat.c": */
	result = _stat( buffer, &buf );

	/* Check if statistics are valid: */
	if( result != 0 )
		perror( "Problem getting information" );
	else
	{
		/* Output some of the statistics: */
		printf( "File size     : %ld\n", buf.st_size );
		printf( "Drive         : %c:\n", buf.st_dev + 'A' );
		printf( "Time modified : %s", ctime( &buf.st_atime ) );
	}

	fcloseall();



	if( (a= (unsigned char*)malloc( buf.st_size )) == NULL)
		return;

	if(  (out=fopen("a1.jpg", "wb"))==NULL || (comp_out=fopen("a1.huf", "rb"))==NULL  )
	{
		fcloseall();
		return;
	}



	//////////////////////////////////////////////////////////////////////////////////////




	memset(a, 0x0, buf.st_size);
	fread(a, buf.st_size, 1, comp_out);

	//////////////////////////////////////////////////////////////////////////////////////
	unsigned char *original_data;
	int  size;
	DeCompress(a , &original_data , &size );


	

	//////////////////////////////////////////////////////////////////////////////////////
	fwrite(original_data, size, 1, out);

	printf("\n");

	//////////////////////////////////////////////////////////////////////////////////////

	Close_Compress_Decompress(original_data);	

	free(a);


	fclose(out);
	fclose(comp_out);

	printf("the end");

}


void main(int argc , char *argv[])
{
#if 0
	int a[256] ;

	int x, y ;

	for ( x = 0; x < 256; x++)
		a[x] = x;

	for( x = -1; x <= 256; x++)
	{
		y = bin(a, 256, x);
		printf("[%d]\n", y);
	}
	
	main2();
#endif
	///////////////////////////////
	FILE *in, *out, *comp_out;
	unsigned char *a = NULL;
	unsigned char *compressed_data = NULL;

	struct _stat buf;
	int result;

	if (argc !=4)
		return;

	/* Get data associated with "stat.c": */
	result = _stat( argv[2], &buf );

	/* Check if statistics are valid: */
	if( result != 0 )
		perror( "Problem getting information" );
	else
	{
		/* Output some of the statistics: */
		printf( "File size     : %ld\n", buf.st_size );
		printf( "Drive         : %c:\n", buf.st_dev + 'A' );
		printf( "Time modified : %s", ctime( &buf.st_atime ) );
	}

	fcloseall();

	if(!strcmp(argv[1], "c"))
	{

		if( (a= (unsigned char*)malloc( buf.st_size )) == NULL)
			return;

		if( (in = fopen(argv[2], "rb")) == NULL || (comp_out=fopen(argv[3], "wb"))==NULL  )
		{
			fcloseall();
			return;
		}

		fread(a, buf.st_size, 1, in);


		//////////////////////////////////////////////////////////////////////////////////////
		int comp_size;
		compressed_data = Compress ( a, buf.st_size, &comp_size);
		
		fwrite(compressed_data, comp_size, 1, comp_out);

		Close_Compress_Decompress(compressed_data);
		fcloseall();
		free(a);


	}

	if(!strcmp(argv[1], "x"))
	{

		/* Get data associated with "stat.c": */
		result = _stat( argv[2], &buf );

		/* Check if statistics are valid: */
		if( result != 0 )
			perror( "Problem getting information" );
		else
		{
			/* Output some of the statistics: */
			printf( "File size     : %ld\n", buf.st_size );
			printf( "Drive         : %c:\n", buf.st_dev + 'A' );
			printf( "Time modified : %s", ctime( &buf.st_atime ) );
		}

		fcloseall();



		if( (a= (unsigned char*)malloc( buf.st_size )) == NULL)
			return;

		if(  (in=fopen(argv[2], "rb"))==NULL || (out=fopen(argv[3], "wb"))==NULL  )
		{
			fcloseall();
			free(a);
			return;
		}



		//////////////////////////////////////////////////////////////////////////////////////




		memset(a, 0x0, buf.st_size);
		fread(a, buf.st_size, 1, in);

		//////////////////////////////////////////////////////////////////////////////////////
		unsigned char *original_data;
		int  size;
		DeCompress(a , &original_data , &size );


		

		//////////////////////////////////////////////////////////////////////////////////////
		fwrite(original_data, size, 1, out);

		printf("\n");

		//////////////////////////////////////////////////////////////////////////////////////

		Close_Compress_Decompress(original_data);	

		free(a);
		fcloseall();

		printf("the end");


	}





}



