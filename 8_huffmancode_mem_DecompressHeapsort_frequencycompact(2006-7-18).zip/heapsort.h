#ifndef _HEAPSORT_H_

#define _HEAPSORT_H_

#include "data_type.h"

/***************************************************************************
[ Horowitz Program modified By sungtae park]
Ư¡ : n���� ����Ÿ��Ʈ. list[0]���� list[n-1]������ Heap Sort�Ѵ�.
______________________________________________________________________
 ��  i = [0, n-1]
 1) root��ȣ�� child��ȣ ���ϱ�.
 root��ȣ        : int i  == (2i + 1 - 1)/2 == ( 2i + 2 - 1)/2
 left child��ȣ  : 2i + 1
 right child��ȣ : 2i + 2
 ***************************************************************************/

// -------------------------------------------------------------------------------------------
// [1]. Int Type  S W A P
// -------------------------------------------------------------------------------------------
void heapsort(int keys[], int N);


// -------------------------------------------------------------------------------------------
// [2]. All Type  S W A P
// -------------------------------------------------------------------------------------------


void HeapSort( void *base, int N, int width, int (__cdecl *compare )(const void *elem1, const void *elem2 ) );


// -------------------------------------------------------------------------------------------
// [2]. All Type  Priority Queue
// -------------------------------------------------------------------------------------------

bool InsertHeap( const void *base, int *N, int width, const void *data_item , int (__cdecl *compare )(const void *elem1, const void *elem2 ) );

bool DeleteHeap( const void *base, int *N, int width, void *del_item , int (__cdecl *compare )(const void *elem1, const void *elem2 ) );
bool DeleteHeapPos( const void *base, int *N, int width, void *del_item ,int del_num, int (__cdecl *compare )(const void *elem1, const void *elem2 ) );

bool HeapSortR( const void *base,  int N, int width, void * dest_data , int (__cdecl *compare )(const void *elem1, const void *elem2 ) );

#if 0
bool HeapSortNR( void *base, int N, int width, int (__cdecl *compare )(const void *elem1, const void *elem2 ) );
#endif

#endif