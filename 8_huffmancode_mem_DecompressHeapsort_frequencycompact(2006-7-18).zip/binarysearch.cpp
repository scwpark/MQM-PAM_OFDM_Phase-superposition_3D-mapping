#include "binarysearch.h"
#include "data_type.h"

int bin(int *arr, int size, int val)
{
	int left = 0;
	int right = size-1;
	int mid = 0;

	while (left <= right) 
	{
		if (  right - left  <=1 )
			mid = left;
		else
		{
#if 0
			if ( mid <= right )
				mid += (right - left)/2 ;
			else
				mid -= (right - left)/2 ;
#else

			mid = left + (right - left)/2 ;
#endif
		}

		if (arr[mid] == val) 
			return mid;
		else if (arr[mid] > val) 
		{
			right = mid - 1;
		}
		else 
		{
			left = mid + 1;
		} 
	}

	return -1;
}


int BinarySearch( void *base, int N, int width, void *val, int (__cdecl *compare )(const void *elem1, const void *elem2 ) )
{

	int root;
	int count;


	int left = 0;
	int right = N -1;
	int mid = 0;
	int result;
	while (left <= right) 
	{
		if (  right - left  <=1 )
			mid = left;
		else
			mid = left + (right - left)/2 ;

		result = compare( (UCHAR *) base + mid*width, val );
		if( result == 0)
			return mid;
		else if (result  == 1) 
		{
			right = mid - 1;
		}
		else 
		{
			left = mid + 1 ;
		} 
	}

	return -1;

}
